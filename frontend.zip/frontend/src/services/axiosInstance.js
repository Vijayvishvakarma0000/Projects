import axios from "axios";

const axiosInstance = axios.create({
  baseURL: "http://192.168.1.45:5000", // ⚠️ apne backend ka port yahan rakho
  headers: {
    "Content-Type": "application/json",
  },
});

// 🔐 Token interceptor (future APIs ke liye ready)
axiosInstance.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem("token");
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

export default axiosInstance;
